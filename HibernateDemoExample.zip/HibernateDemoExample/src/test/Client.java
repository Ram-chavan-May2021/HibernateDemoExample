package test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import beans.Employee;
import beans.Student;

public class Client {
	
	public static void main(String[] args) {
		
		Student st=new Student();
		st.setId(113);
		st.setName("Ram");
		st.setEmail("ramchavan@gmail.com");
		st.setMarks("60");
		
		Employee em=new Employee();
		em.setId(114);
		em.setName("Pooja");
		em.setEmail("poojadarade@gmail.com");
		em.setSalary("25000");
		
		Configuration cfg=new Configuration();
		cfg.configure("resources/hibernate.cfg.xml");
		
		SessionFactory sf=cfg.buildSessionFactory();
		Session session=sf.openSession();
		session.save(st);
		session.save(em);
		
		session.beginTransaction().commit();
		System.out.println("Suceefully inserted...");
		
		session.close();
		sf.close();
		
		
		
	}

}
